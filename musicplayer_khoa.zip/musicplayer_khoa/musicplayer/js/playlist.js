let songs = [
  {
    name: "Merry Go Round Of Life",
    artist: "Joe Hisaishi",
    img: "merry_go_round_of_life",
    img: "merry_go_round_of_life",
    audio: "merry_go_round_of_life"
  },
  {
    name: "A Town With An Ocean View",
    artist: "Joe Hisaishi",
    
    img: "a_town_with_an_ocean_view",
    audio: "a_town_with_an_ocean_view"
  },
  {
    name: "Always With Me",
    artist: "Joe Hisaishi",
    img: "always_with_me",
    audio: "always_with_me"
  }
  
]